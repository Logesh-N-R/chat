<?php
session_start();
if (!empty($_SESSION)) {
    if (isset($_POST['submit']) && $_POST['submit'] == 'Chat') {
        if (isset($_POST['email']) && empty($_POST['email'])) {
            $message = [
                "status" => "failed",
                "data" => ["email" => "Plese enter user mail id"]
            ];
        } else if ($_POST['email'] == $_SESSION['email']) {
            $message = [
                "status" => "failed",
                "data" => ["email" => "This is your mail id!"]
            ];
        } else {
            include "dbConnect.php";
            $email = $_POST['email'];
            $sql = "SELECT `sno` , `name` , `img` FROM `user_register` WHERE BINARY `email` = '$email'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $user = $row["sno"];
                    $img = (isset($row["img"])) ? $row["img"] : "uploads/default.jpg";;
                    $name = $row["name"];
                }
                $_SESSION['chatWith'] = $user;
                $_SESSION['chatWithName'] = $name;
                $_SESSION['chatWithImg'] = $img;
                $message = [
                    "status" => "success",
                    "data" => ["chatWith" => $user]
                ];
            } else {
                $message = [
                    "status" => "failed",
                    "data" => ["email" => "User does not exist!"]
                ];
            }
        }
        print_r(json_encode($message));
    }
} else {
    $message = [
        "status" => "failed",
        "data" => ["topage" => "login.html"]
    ];
    print_r(json_encode($message));
}
