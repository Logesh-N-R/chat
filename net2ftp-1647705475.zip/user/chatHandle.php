<?php
session_start();
include "dbConnect.php";
if (!empty($_SESSION)) {
    if (isset($_POST['refresh']) && $_POST['refresh'] == 'true') {
        $outPutJson = [
            "user1" => [
                "name" => $_SESSION['name'],
                "email" => $_SESSION['email'],
                "dp" => $_SESSION['image']
            ],
            "user2" => [
                "name" => $_SESSION['chatWithName'],
                "email" => $_SESSION['email'],
                "dp" => $_SESSION['chatWithImg']
            ]
        ];

        $currentUser = $_SESSION["id"];
        $targetUser = $_SESSION["chatWith"];
        $sql = "SELECT message,sent_time,msg_from FROM userchats WHERE (msg_from = $currentUser AND msg_to = $targetUser) OR (msg_from = $targetUser AND msg_to = $currentUser) ORDER BY sent_time DESC";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                if ($row["msg_from"] == $currentUser) {
                    $date = new DateTime($row['sent_time']);
                    $outPutJson['content'][] = ['user1' => base64_decode($row["message"]), 'time' => $date->format('h:i:s'), 'day' => $date->format('Y-m-d')];
                } else {
                    $date = new DateTime($row['sent_time']);
                    $outPutJson['content'][] = ['user2' => base64_decode($row["message"]), 'time' => $date->format('h:i:s'), 'day' => $date->format('Y-m-d')];
                }
            }
        }
        print_r(json_encode($outPutJson));
    }
    if (isset($_POST['send']) && $_POST['send'] == 'true' && isset($_SESSION)) {
        if (isset($_POST['message']) && !empty($_POST['message'])) {
            $message = $_POST['message'];
            $from = $_SESSION['id'];
            $to = $_SESSION['chatWith'];
            $message = base64_encode($_POST['message']);
            $sql = "INSERT INTO `userchats` (`sno`, `msg_from`, `msg_to`, `message`, `sent_time`) 
        VALUES ('0', '$from', '$to', '$message', current_timestamp())";
            $result = mysqli_query($conn, $sql);
        }
    }
    if (isset($_POST['delete']) && $_POST['delete'] == 'true' && isset($_SESSION)) {
        $currentUser = $_SESSION["id"];
        $targetUser = $_SESSION["chatWith"];
        $sql = "DELETE FROM `userchats` WHERE (`userchats`.`msg_from` = $currentUser AND `userchats`.`msg_to` = $targetUser) OR (`userchats`.`msg_from` = $targetUser AND `userchats`.`msg_to` = $currentUser) ";
        $result = $conn->query($sql);
        echo("Error description: " . $conn -> error);
    }
} else {
    $message = [
        "status" => "failed",
        "data" => ["topage" => "login.html"]
    ];
    print_r(json_encode($message));
}
