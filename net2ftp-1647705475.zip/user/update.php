<?php
include "dbConnect.php";
session_start();
if (!empty($_SESSION)) {
    if (isset($_POST['update']) && $_POST['update'] == 'true') {
        $id = $_SESSION['id'];
        $sql = "SELECT name , phone FROM user_register WHERE sno = '$id'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $message = [
                "status" => "success",
                "data" => ['name' => $row["name"], 'phone' => $row['phone']]
            ];
            print_r(json_encode($message));
        }
    }else if (isset($_POST['recentusers']) && $_POST['recentusers'] == 'true') {
        $id = $_SESSION['id'];
        $sql =  "SELECT DISTINCT user_register.email 
                FROM user_register 
                INNER JOIN userchats 
                ON userchats.msg_to = user_register.sno OR userchats.msg_from = user_register.sno
                WHERE userchats.msg_from=$id OR userchats.msg_to=$id";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                if($row["email"] != $_SESSION['email']){
                    $chatUsers[] = $row["email"];
                }
            }
            $message = [
                "status" => "success",
                "data" => ['mail' => $chatUsers]
            ];
            print_r(json_encode($message));
        }
    }
     else if (isset($_POST['submit']) && $_POST['submit'] == "Update") {
        $error = [];
        if (!isset($_POST['name']) || empty($_POST['name'])) {
            $error['name'] = "Enter Name";
        }
        if (isset($_POST['phone']) && !empty($_POST['phone'])) {
            if (strlen($_POST['phone']) < 8) {
                $error['phone'] = "Phone should be atlease 8 charecters";
            }
        } else {
            $error['phone'] = "Enter Phone number";
        }
        if (empty($error)) {
            $id = $_SESSION['id'];
            $name = $_POST['name'];
            $phone = $_POST['phone'];
            $sql = "UPDATE user_register SET name = '$name' ,phone = '$phone' WHERE sno = $id";
            $result = mysqli_query($conn, $sql);
            $conn->close();
            if ($result == 1) {
                $message = [
                    "status" => "success",
                    "data" => ["update" => "Successfully Updated!"]
                ];
            } else {
                $message = [
                    "status" => "success",
                    "data" => ["update" => "Update failed!"]
                ];
            }
            print_r(json_encode($message));
        } else {
            $message = [
                "status" => "failed",
                "data" => $error
            ];
            print_r(json_encode($message));
        }
    } else if (isset($_POST['submit']) && $_POST['submit'] == "UpdatePW") {
        $error = [];
        if (isset($_POST['password']) && !empty($_POST['password'])) {
            if (strlen($_POST['password']) < 8) {
                $error['password'] = "Password should be 8 charecters";
            }
        } else {
            $error['password'] = "Enter Password";
        }
        if (empty($error)) {
            $id = $_SESSION['id'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $oldPassword = $_POST['oldpassword'];
            $sql = "SELECT password FROM user_register WHERE sno = '$id'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $dbPassword = $row["password"];
                if (password_verify($oldPassword, $dbPassword)) {
                    $sql = "UPDATE user_register SET  password = '$password' WHERE sno = $id";
                    $result = mysqli_query($conn, $sql);
                    $conn->close();
                    if ($result == 1) {
                        $message = [
                            "status" => "success",
                            "data" => ["update" => "Password Changed!"]
                        ];
                    } else {
                        $message = [
                            "status" => "success",
                            "data" => ["update" => "Update failed!"]
                        ];
                    }
                    print_r(json_encode($message));
                } else {
                    $message = [
                        "status" => "success",
                        "data" => ["update" => "Current Password is wrong!"]
                    ];
                    print_r(json_encode($message));
                }
            }
        } else {
            $message = [
                "status" => "failed",
                "data" => $error
            ];
            print_r(json_encode($message));
        }
    }
} else {
    $message = [
        "status" => "failed",
        "data" => ["topage" => "login.html"]
    ];
    print_r(json_encode($message));
}
