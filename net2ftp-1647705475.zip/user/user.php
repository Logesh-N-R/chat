<?php
session_start();
include "dbConnect.php";
if(isset($_SESSION)){
$id = $_SESSION['id'];
    $sql = "SELECT img FROM user_register WHERE sno = '$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
            $row=$result->fetch_assoc();
            $message = [
                "status" => "success",
                "data" => ['img'=>$row["img"],'name'=>$_SESSION['name'],'id'=>$_SESSION['id']]
            ];
            print_r(json_encode($message));
    }else{
        $message = [
            "status" => "failed",
            "data" => ["response"=>"no user registed on this user name"]
        ];
        print_r(json_encode($message));
    }
$conn->close();
}else{
    $message = [
        "status" => "failed",
    ];
    print_r(json_encode($message));
}

