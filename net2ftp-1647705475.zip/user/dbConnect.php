<?php
$servername = "localhost";
$username = "360948";
$password = "logeshnr07";
$conn = new mysqli($servername, $username, $password, '360948');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
